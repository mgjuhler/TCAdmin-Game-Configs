resource_type 'map' { gameTypes = { race = true } }

map 'map.lua'
